package com.teama.walkinclinic;

public class Administrator {

    public Administrator(){}

}
