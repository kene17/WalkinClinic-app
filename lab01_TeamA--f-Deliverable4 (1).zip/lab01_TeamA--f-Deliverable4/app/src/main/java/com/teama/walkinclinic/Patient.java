package com.teama.walkinclinic;

public class Patient extends User
{


    public Patient(String firstName, String lastName, String emailAddress){
        super(firstName, lastName, emailAddress);
    }

    public Patient(){}



}
