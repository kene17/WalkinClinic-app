package com.teama.walkinclinic;

public class Employee extends User
{
    public Employee(String firstName, String lastName, String emailAddress){
    this.firstName = firstName;
    this.lastName = lastName;
    this.emailAddress = emailAddress;

}
    public Employee(){}




}
